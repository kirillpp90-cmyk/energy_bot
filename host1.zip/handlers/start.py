from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        f"Привет, {message.from_user.full_name}!\n\n"
        "⚡ Это бот-калькулятор энергопотребления\n\n"
        "Используй команду /calc чтобы начать расчёт мощности прибора.\n\n"
        "Используйте команду /about чтобы узнать подробнее о боте"
    )

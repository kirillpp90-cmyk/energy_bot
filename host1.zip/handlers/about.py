from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

@router.message(Command('about'))
async def about(message: Message):
    await message.answer(f'ℹ️ Бот-калькулятор энергопотребления\n\n'
                         'Версия 1.0\n\n'
                         f'Автор: {message.from_user.full_name}\n'
                         'Команды: /start, /calc, /about')
